#!/bin/sh
java -jar IJProductSampleRestServiceOnTheFly-1.1.20210428.1.jar 9999